/*
Nombre: Axel Octavio Sumpango Cunil
Código Técnico: IN5AV
Fecha de Creación: 27-09-2022
Fecha de Modificación: 27-09-2022
 */
package org.axelsumpango.system;

import java.io.InputStream;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.axelsumpango.controller.MenuPrincipalController;
import org.axelsumpango.controller.VecinoController;
import org.axelsumpango.controller.VehiculoController;


/**
 *
 * @author irisc
 */
public class Principal extends Application {
    
    private Stage escenarioPrincipal;
    private Scene escena;
    private final String PAQUETE_VISTA = "/org/axelsumpango/view/";



    @Override
        public void start(Stage escenarioPrincipal) throws Exception {
        this.escenarioPrincipal = escenarioPrincipal;
        this.escenarioPrincipal.setTitle("EMETRA");
        escenarioPrincipal.getIcons().add(new Image("/org/axelsumpango/image/logo-pmt.png"));
        ventanaMenuPrincipal();
        escenarioPrincipal.show();
    }
     
    public void ventanaMenuPrincipal(){
        try{
            MenuPrincipalController menuPrincipal = (MenuPrincipalController)cambiarEscena("MenuPrincipalView.fxml", 600, 400);
            menuPrincipal.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Error en ventanaMenuPrincipal");
        }
    }   
    
    public void ventanaVecinos(){
        try{
            VecinoController vistaVecinos = (VecinoController) cambiarEscena("VecinoView.fxml", 1100, 400);
            vistaVecinos.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Error en ventanaVecinos de Principal");
        }
    }
    
    public void ventanaVehiculos(){
        try{
            VehiculoController vistaVehiculos = (VehiculoController) cambiarEscena("VehiculoView.fxml", 799, 400);
            vistaVehiculos.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Error en ventanaVehiculos de Prinicipal");
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
    public Initializable cambiarEscena(String fxml, int ancho, int alto) throws Exception{
        Initializable resultado = null;
        FXMLLoader cargadorFXML = new FXMLLoader();
        InputStream archivo = Principal.class.getResourceAsStream(PAQUETE_VISTA+fxml);
        cargadorFXML.setBuilderFactory (new JavaFXBuilderFactory());
        cargadorFXML.setLocation(Principal.class.getResource(PAQUETE_VISTA+fxml));
        escena = new Scene((AnchorPane)cargadorFXML.load(archivo), ancho, alto);
        escenarioPrincipal.setScene(escena);
        escenarioPrincipal.sizeToScene();
        resultado = (Initializable)cargadorFXML.getController();
        return resultado;
    }
    
}
