package org.axelsumpango.controller;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;
import org.axelsumpango.bean.Vecino;
import org.axelsumpango.db.Conexion;
import org.axelsumpango.system.Principal;


public class VecinoController implements Initializable{
    private Principal escenarioPrincipal;
    private enum operaciones{NUEVO,ELIMINAR,EDITAR,GUARDAR,ACTUALIZAR,CANCELAR,NINGUNO};
    private operaciones tipoDeOperacion = operaciones.NINGUNO;
    private ObservableList<Vecino> listaVecinos;
    
    @FXML private TextField txtNITVecino;
    @FXML private TextField txtDPIVecino;
    @FXML private TextField txtNombresVecino;
    @FXML private TextField txtApellidosVecino;
    @FXML private TextField txtDireccionVecino;
    @FXML private TextField txtMunicipalidadVecino;
    @FXML private TextField txtCodigoPostal;
    @FXML private TextField txtTelefonoVecino;
    @FXML private TableView tblVecinos;
    @FXML private TableColumn colNITVecino;
    @FXML private TableColumn colDPIVecino;
    @FXML private TableColumn colNombresVecino;
    @FXML private TableColumn colApellidosVecino;
    @FXML private TableColumn colDireccionVecino;
    @FXML private TableColumn colMunicipalidadVecino;
    @FXML private TableColumn colCodigoPostal;
    @FXML private TableColumn colTelefono;
    @FXML private Button btnNuevo;
    @FXML private Button btnEliminar;
    @FXML private Button btnEditar;
    @FXML private Button btnReporte;
    
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
    }
    
    public void cargarDatos(){
        tblVecinos.setItems(getVecino());
        colNITVecino.setCellValueFactory(new PropertyValueFactory<Vecino, String>("NIT"));
        colDPIVecino.setCellValueFactory(new PropertyValueFactory<Vecino, String>("DPI"));
        colNombresVecino.setCellValueFactory(new PropertyValueFactory<Vecino, String>("nombres"));
        colApellidosVecino.setCellValueFactory(new PropertyValueFactory<Vecino, String>("apellidos"));
        colDireccionVecino.setCellValueFactory(new PropertyValueFactory<Vecino, String>("direccion"));
        colMunicipalidadVecino.setCellValueFactory(new PropertyValueFactory<Vecino, String>("municipalidad"));
        colCodigoPostal.setCellValueFactory(new PropertyValueFactory<Vecino, Integer>("codigoPostal"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<Vecino, String>("telefono"));
    }
    
    public void seleccionarElemento(){
        if(tblVecinos.getSelectionModel().getSelectedItem() != null){
        try{
        txtNITVecino.setText(((Vecino)tblVecinos.getSelectionModel().getSelectedItem()).getNIT());    
        txtDPIVecino.setText(((Vecino)tblVecinos.getSelectionModel().getSelectedItem()).getDPI());
        txtNombresVecino.setText(((Vecino)tblVecinos.getSelectionModel().getSelectedItem()).getNombres());
        txtApellidosVecino.setText(((Vecino) tblVecinos.getSelectionModel().getSelectedItem()).getApellidos());
        txtDireccionVecino.setText(((Vecino)tblVecinos.getSelectionModel().getSelectedItem()).getDireccion());
        txtMunicipalidadVecino.setText(((Vecino)tblVecinos.getSelectionModel().getSelectedItem()).getMunicipalidad());
        txtCodigoPostal.setText(String.valueOf(((Vecino)tblVecinos.getSelectionModel().getSelectedItem()).getCodigoPostal()));
        txtTelefonoVecino.setText(((Vecino)tblVecinos.getSelectionModel().getSelectedItem()).getTelefono());
        }catch(Exception e){
            e.printStackTrace();
        }
        }else{
            JOptionPane.showMessageDialog(null, "Por favor seleccione un lugar con registros");
        }
    }
    
    public ObservableList<Vecino> getVecino(){
        ArrayList<Vecino> lista = new ArrayList<Vecino>();
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_ListarVecinos}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Vecino(resultado.getString("NIT"),
                                    resultado.getString("DPI"),
                                    resultado.getString("nombres"),
                                    resultado.getString("apellidos"),
                                    resultado.getString("direccion"),
                                    resultado.getString("municipalidad"),
                                    resultado.getInt("codigoPostal"),
                                    resultado.getString("telefono")));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return listaVecinos = FXCollections.observableArrayList(lista);
    }
    
    public void nuevo(){
        switch(tipoDeOperacion){
            case NINGUNO:
                activarControles();
                limpiarControles();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                btnEditar.setDisable(true);
                btnReporte.setDisable(true);
                tipoDeOperacion = operaciones.GUARDAR;
                break;
            case GUARDAR:
                guardar();
                desactivarControles();
                limpiarControles();
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                tipoDeOperacion = operaciones.NINGUNO;
                cargarDatos();
                break;
            case CANCELAR:
                desactivarControles();
                limpiarControles();
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                tipoDeOperacion = operaciones.GUARDAR;
                cargarDatos();
                break;
               
        }
    } 
    
    public void guardar(){
        Vecino registro = new Vecino();
        registro.setNIT(txtNITVecino.getText());
        registro.setDPI(txtDPIVecino.getText());
        registro.setNombres(txtNombresVecino.getText());
        registro.setApellidos(txtApellidosVecino.getText());
        registro.setDireccion(txtDireccionVecino.getText());
        registro.setMunicipalidad(txtMunicipalidadVecino.getText());
        registro.setCodigoPostal(Integer.parseInt(txtCodigoPostal.getText()));
        registro.setTelefono(txtTelefonoVecino.getText());
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_AgregarVecino(?, ?, ?, ?, ?, ?, ?, ?)}");
            procedimiento.setString(1, registro.getNIT());
            procedimiento.setString(2, registro.getDPI());
            procedimiento.setString(3, registro.getNombres());
            procedimiento.setString(4, registro.getApellidos());
            procedimiento.setString(5, registro.getDireccion());
            procedimiento.setString(6, registro.getMunicipalidad());
            procedimiento.setInt(7, registro.getCodigoPostal());
            procedimiento.setString(8, registro.getTelefono());
            procedimiento.execute();
            listaVecinos.add(registro);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void eliminar(){
        switch (tipoDeOperacion){
            case GUARDAR:
                desactivarControles();
                limpiarControles();
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                tipoDeOperacion = operaciones.NINGUNO;
                break;
            default: 
                if(tblVecinos.getSelectionModel().getSelectedItem() != null){
                    int respuesta = JOptionPane.showConfirmDialog(null, "¿Está seguro de eliminar el registro?", "Eliminar Vecino", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if(respuesta == JOptionPane.YES_OPTION){
                        try{
                            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_EliminarVecino(?)}");
                            procedimiento.setString(1,((Vecino)tblVecinos.getSelectionModel().getSelectedItem()).getNIT());
                            procedimiento.execute();
                            listaVecinos.remove(tblVecinos.getSelectionModel().getSelectedIndex());
                            limpiarControles();
                        }catch(Exception e){
                            e.printStackTrace();
                            System.out.println("Error en el metodo eliminar de VecinoController");
                        }
                    }else if(respuesta== JOptionPane.NO_OPTION){
                        limpiarControles();
                        tipoDeOperacion =operaciones.NINGUNO;
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento");
                }
                break;
        }
                
    } 
    
    public void editar(){
        switch(tipoDeOperacion){
            case NINGUNO:
                if(tblVecinos.getSelectionModel().getSelectedItem() != null){
                    btnEditar.setText("Actualizar");
                    btnReporte.setText("Cancelar");
                    btnNuevo.setDisable(true);
                    btnEliminar.setDisable(true);
                    activarControles();
                    txtNITVecino.setEditable(false);
                    tipoDeOperacion = operaciones.ACTUALIZAR;
                }else{
                    JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento");
                }
                break;
            case ACTUALIZAR:
                actualizar();
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                desactivarControles();
                limpiarControles();
                tipoDeOperacion = operaciones.NINGUNO;
                cargarDatos();
                break;
        }
    }
    
    public void actualizar(){
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_EditarVecino(?,?,?,?,?,?,?,?)}");
            Vecino registro = (Vecino)tblVecinos.getSelectionModel().getSelectedItem();
            registro.setDPI(txtDPIVecino.getText());
            registro.setNombres(txtNombresVecino.getText());
            registro.setApellidos(txtApellidosVecino.getText());
            registro.setDireccion(txtDireccionVecino.getText());
            registro.setMunicipalidad(txtMunicipalidadVecino.getText());
            registro.setCodigoPostal(Integer.parseInt(txtCodigoPostal.getText()));
            registro.setTelefono(txtTelefonoVecino.getText());
            procedimiento.setString(1, registro.getNIT());
            procedimiento.setString(2, registro.getDPI());
            procedimiento.setString(3, registro.getNombres());
            procedimiento.setString(4, registro.getApellidos());
            procedimiento.setString(5, registro.getDireccion());
            procedimiento.setString(6, registro.getMunicipalidad());
            procedimiento.setInt(7, registro.getCodigoPostal());
            procedimiento.setString(8, registro.getTelefono());
            procedimiento.execute();
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Error en el metodo actualizar de VecinoController");
        }
    }
    
    public void reporte(){
        switch(tipoDeOperacion){
            case ACTUALIZAR:
                desactivarControles();
                limpiarControles();
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                tipoDeOperacion = operaciones.NINGUNO;
                break;
        }
    }
    
    public void desactivarControles(){
        txtNITVecino.setEditable(false);
        txtDPIVecino.setEditable(false);
        txtNombresVecino.setEditable(false);
        txtApellidosVecino.setEditable(false);
        txtDireccionVecino.setEditable(false);
        txtMunicipalidadVecino.setEditable(false);
        txtCodigoPostal.setEditable(false);
        txtTelefonoVecino.setEditable(false);
    }
    
    public void activarControles(){
        txtNITVecino.setEditable(true);
        txtDPIVecino.setEditable(true);
        txtNombresVecino.setEditable(true);
        txtApellidosVecino.setEditable(true);
        txtDireccionVecino.setEditable(true);
        txtMunicipalidadVecino.setEditable(true);
        txtCodigoPostal.setEditable(true);
        txtTelefonoVecino.setEditable(true);
    }
    
    public void limpiarControles(){
        txtNITVecino.clear();
        txtDPIVecino.clear();
        txtNombresVecino.clear();
        txtApellidosVecino.clear();
        txtDireccionVecino.clear();
        txtMunicipalidadVecino.clear();
        txtCodigoPostal.clear();
        txtTelefonoVecino.clear();
        tblVecinos.getSelectionModel().clearSelection();
    }
    

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void ventanaMenuPrincipal(){
        escenarioPrincipal.ventanaMenuPrincipal();
    }
}    
    